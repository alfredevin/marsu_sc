<!-- Page Content -->
<div class="container-fluid fade-in-up">

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800 font-weight-bold">Academic History Records</h1>
            <p class="text-xs text-gray-600 mb-0">Longitudinal term-by-term GPA, cumulative units completed, and
                institutional academic standing records.</p>
        </div>
        <div class="mt-3 mt-sm-0">
            <button class="btn btn-sm btn-outline-primary shadow-sm" onclick="window.print()">
                <i class="fas fa-print fa-sm mr-1"></i> Print Transcript Summary
            </button>
        </div>
    </div>

    <!-- KPI Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-primary h-100 shadow-sm">
                <div class="kpi-label text-primary">Average Cohort GPA</div>
                <div class="kpi-number text-gray-900" id="kpiAvgGpa">2.34</div>
                <div class="text-xs text-muted mt-1">MarSU 1.00 - 5.00 grading scale</div>
                <i class="fas fa-graduation-cap kpi-icon"></i>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-success h-100 shadow-sm">
                <div class="kpi-label text-success">Dean's List Honorees</div>
                <div class="kpi-number text-gray-900" id="kpiDeansList">3</div>
                <div class="text-xs text-muted mt-1">GPA &le; 1.75 with zero deficiencies</div>
                <i class="fas fa-award kpi-icon"></i>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-warning h-100 shadow-sm">
                <div class="kpi-label text-warning">Academic Warning</div>
                <div class="kpi-number text-gray-900" id="kpiWarning">2</div>
                <div class="text-xs text-muted mt-1">GPA 2.75 - 3.00</div>
                <i class="fas fa-exclamation-triangle kpi-icon"></i>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-danger h-100 shadow-sm">
                <div class="kpi-label text-danger">Probationary Standing</div>
                <div class="kpi-number text-gray-900" id="kpiProbation">2</div>
                <div class="text-xs text-muted mt-1">Units passed &lt; 70% threshold</div>
                <i class="fas fa-user-slash kpi-icon"></i>
            </div>
        </div>
    </div>

    <!-- Main Academic History Table Card -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-wrap align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">
                <i class="fas fa-history mr-1"></i> Term Standing & Transcript Registry
            </h6>
            <div class="btn-group btn-group-sm mt-2 mt-sm-0">
                <button type="button" class="btn btn-outline-secondary term-filter active" data-term="all">All
                    Terms</button>
                <button type="button" class="btn btn-outline-secondary term-filter" data-term="AY 2025-2026 S1">AY
                    2025-2026 S1</button>
                <button type="button" class="btn btn-outline-secondary term-filter" data-term="AY 2024-2025 S2">AY
                    2024-2025 S2</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="academicHistoryTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Academic Term</th>
                            <th class="text-center">Term GPA</th>
                            <th class="text-center">Cumulative GPA</th>
                            <th class="text-center">Units Enrolled / Passed</th>
                            <th class="text-center">Standing</th>
                            <th class="text-center">Honors</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody id="academicHistoryTableBody">
                        <!-- Loaded via MarSUDataStore -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>