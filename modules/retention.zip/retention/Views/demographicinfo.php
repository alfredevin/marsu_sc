<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800 font-weight-bold">Grades Tracking & Class Record</h1>
            <p class="text-xs text-gray-600 mb-0">MarSU CICS Class Record & Dynamic Evaluation Matrix &bull; Official
                grading sheet, assessment criteria weighting, and multi-factor retention risk evaluation.</p>
        </div>
        <div class="mt-3 mt-sm-0 btn-toolbar-group">
            <button class="btn btn-sm btn-outline-primary shadow-sm" data-toggle="modal" data-target="#schemeModal"
                id="btnTopOpenSchemeModal">
                <i class="fas fa-sliders-h mr-1"></i> Customize Grading Policy
            </button>
            <a href="student-roster.html" class="btn btn-sm btn-outline-danger shadow-sm font-weight-bold">
                <i class="fas fa-exclamation-triangle fa-sm mr-1"></i> View At-Risk Roster
            </a>
            <a href="#quickAssignSubjectSection" class="btn btn-sm btn-primary shadow-sm">
                <i class="fas fa-file-excel fa-sm mr-1"></i> Class Record Grid
            </a>
        </div>
    </div>

    <!-- Philippine Grading System Info Banner -->
    <div class="alert alert-light border-left-primary shadow-sm mb-4">
        <div class="d-flex align-items-center justify-content-between flex-wrap">
            <div class="d-flex align-items-center mb-2 mb-md-0">
                <div class="icon-circle bg-primary text-white mr-3" style="background-color: #6B1D2F !important;">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <div>
                    <h6 class="mb-0 font-weight-bold text-gray-800">State University Academic Grading & Early Warning
                        Threshold</h6>
                    <p class="mb-0 text-xs text-gray-600">
                        Scale: <strong>1.00 - 1.75</strong> (Excellent) &bull; <strong>2.00 - 2.75</strong>
                        (Satisfactory) &bull; <strong>3.00</strong> (Passing Limit) &bull; <strong>3.25 - 4.00</strong>
                        (Deficient / High Risk) &bull; <strong>5.00</strong> (Failed / Critical Risk Trigger).
                    </p>
                </div>
            </div>
            <div>
                <span class="badge badge-danger p-2 mr-1">Grade &gt; 3.00 = At-Risk</span>
                <span class="badge badge-warning text-dark p-2">Attendance &lt; 80% = Flagged</span>
            </div>
        </div>
    </div>

    <!-- Dynamic Excel Spreadsheet Grid: MarSU CICS Official Class Record (for JM (1).xlsx) -->
    <div class="card shadow mb-4" id="quickAssignSubjectSection">
        <!-- Spreadsheet Header Banner matching Excel Template -->
        <div class="card-header py-3 bg-white border-bottom">
            <div class="d-flex flex-column flex-lg-row align-items-lg-center justify-content-between">
                <div class="mb-2 mb-lg-0">
                    <div class="d-flex align-items-center">
                        <div class="icon-circle bg-primary text-white mr-2"
                            style="background-color: #6B1D2F !important; width: 2.2rem; height: 2.2rem;">
                            <i class="fas fa-file-excel fa-sm"></i>
                        </div>
                        <div>
                            <h6 class="m-0 font-weight-bold text-primary" style="color: #6B1D2F !important;">
                                MarSU CICS Class Record & Dynamic Evaluation Matrix
                            </h6>
                            <div class="text-xs text-muted">
                                Based on MarSU CICS Official Template (<code>for JM (1).xlsx</code>) &bull; A.Y.
                                2026-2027 &bull; Linear Formula: <code>-4*(Score/Total)+5</code>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center flex-wrap">
                    <div class="mr-2 mb-1 mb-sm-0">
                        <select class="form-control form-control-sm font-weight-bold text-primary"
                            id="selectRosterCourseFilter" style="min-width: 220px;">
                            <!-- Dynamically populated with active courses -->
                        </select>
                    </div>
                    <div class="btn-group btn-group-sm mr-2 mb-1 mb-sm-0">
                        <button class="btn btn-sm btn-outline-secondary" id="filterAll">All</button>
                        <button class="btn btn-sm btn-outline-danger" id="filterCritical">Critical</button>
                        <button class="btn btn-sm btn-outline-warning" id="filterHigh">High</button>
                        <button class="btn btn-sm btn-outline-success" id="filterGood">Good Standing</button>
                    </div>
                    <button class="btn btn-sm btn-outline-secondary shadow-sm mr-2 mb-1 mb-sm-0 font-weight-bold"
                        data-toggle="modal" data-target="#schemeModal">
                        <i class="fas fa-sliders-h mr-1"></i> Customize Scheme
                    </button>
                    <button class="btn btn-sm btn-primary font-weight-bold shadow-sm mb-1 mb-sm-0"
                        id="btnSaveAllTableScores" style="background-color: #6B1D2F; border-color: #6B1D2F;">
                        <i class="fas fa-save mr-1"></i> Save All Grades
                    </button>
                </div>
            </div>

            <!-- Course and Section Info Strip -->
            <div class="d-flex align-items-center justify-content-between mt-2 pt-2 border-top flex-wrap text-xs">
                <div class="d-flex align-items-center flex-wrap">
                    <span class="badge badge-light border text-dark mr-2 px-2 py-1 font-weight-bold">
                        <i class="fas fa-book mr-1 text-primary"></i> Course: <span id="lblExcelCourseHeader">IT211 -
                            Data Structures and Algorithms</span>
                    </span>
                    <span class="badge badge-light border text-dark mr-2 px-2 py-1 font-weight-bold">
                        <i class="fas fa-users mr-1 text-primary"></i> Section: <span id="lblExcelSectionHeader">BSIT
                            2-A</span>
                    </span>
                    <span class="badge badge-light border text-dark mr-2 px-2 py-1 font-weight-bold">
                        <i class="fas fa-sliders-h mr-1 text-primary"></i> Scheme: <span id="lblExcelSchemeName">MarSU
                            CICS Standard</span>
                    </span>
                    <span class="badge badge-danger px-2 py-1 font-weight-bold">
                        Passing Cutoff: &le; <span id="lblExcelCutoffHeader">3.04</span>
                    </span>
                </div>
                <div class="mt-1 mt-md-0 font-weight-bold text-muted">
                    <span id="tableRosterSummary">Displaying enrolled students</span>
                </div>
            </div>
        </div>

        <div class="card-body p-0">
            <!-- Scrollable 2-Tier Excel Spreadsheet Grid -->
            <div class="excel-table-container">
                <table class="excel-table" id="gradeRegistryTable">
                    <thead id="gradeRegistryThead">
                        <!-- 2-Tier Header dynamically rendered based on active scheme -->
                    </thead>
                    <tbody id="gradeRegistryTableBody">
                        <!-- Dynamically populated with interactive score and attendance cells -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Excel Legend Box matching for JM (1).xlsx Template -->
        <div class="card-footer bg-light py-2 px-3 border-top">
            <div class="d-flex align-items-center justify-content-between flex-wrap text-xs">
                <div class="d-flex align-items-center flex-wrap my-1">
                    <strong class="text-dark mr-2"><i class="fas fa-info-circle mr-1" style="color: #6B1D2F;"></i>
                        Legend:</strong>
                    <span class="badge badge-light border text-dark mr-1"><strong>Q</strong> - Quiz</span>
                    <span class="badge badge-light border text-dark mr-1"><strong>ATT</strong> - Attendance</span>
                    <span class="badge badge-light border text-dark mr-1"><strong>A</strong> - Activity</span>
                    <span class="badge badge-light border text-dark mr-1"><strong>G</strong> - Group Activity</span>
                    <span class="badge badge-light border text-dark mr-1"><strong>R</strong> - Recitation</span>
                    <span class="badge badge-light border text-dark mr-1"><strong>P</strong> - Performance</span>
                    <span class="badge badge-light border text-dark mr-1"><strong>MIDTERMS</strong></span>
                    <span class="badge badge-light border text-dark"><strong>FINALS</strong></span>
                </div>
                <div class="d-flex align-items-center flex-wrap my-1 font-weight-bold">
                    <span class="badge badge-light border text-dark mr-2 font-weight-normal">Formula:
                        <code>Grade = -4 * (RawScore / MaxScore) + 5</code></span>
                    <span class="badge badge-success mr-1">Grade &le; <span class="legend-cutoff-val">3.04</span> =
                        PASSED</span>
                    <span class="badge badge-danger">Grade &gt; <span class="legend-cutoff-val">3.04</span> = FAILED
                        (High Risk)</span>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Customize Grading Scheme Modal -->
<div class="modal fade" id="schemeModal" tabindex="-1" role="dialog" aria-labelledby="schemeModalTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header marsu-modal-header text-white">
                <div>
                    <h5 class="modal-title font-weight-bold" id="schemeModalTitle">
                        <i class="fas fa-sliders-h mr-2"></i> Customize Grading Policy & Assessment Scheme
                    </h5>
                    <div class="text-xs text-white-50">Configure assessment component weights, quizzes, activities,
                        exams, attendance dates, and passing threshold.</div>
                </div>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Scope & Presets -->
                <div class="row mb-3 bg-light p-3 rounded border">
                    <div class="col-md-3 mb-2">
                        <label class="text-xs font-weight-bold text-gray-700 text-uppercase">Target Course Code</label>
                        <select class="form-control form-control-sm font-weight-bold" id="modalSelectCourse"></select>
                    </div>
                    <div class="col-md-2 mb-2">
                        <label class="text-xs font-weight-bold text-gray-700 text-uppercase">Year & Section</label>
                        <input type="text" class="form-control form-control-sm font-weight-bold"
                            id="modalInputYearSection" value="BSIT 2-A">
                    </div>
                    <div class="col-md-4 mb-2">
                        <label class="text-xs font-weight-bold text-gray-700 text-uppercase">Presets Dropdown</label>
                        <select class="form-control form-control-sm font-weight-bold text-primary"
                            id="modalSelectPreset">
                            <option value="preset_marsu_cics_default">MarSU CICS Standard Lecture (30% - 30% - 40%)
                            </option>
                            <option value="preset_lecture_lab">Lecture with Laboratory (20% Quizzes, 40% Lab Output, 40%
                                Exams)</option>
                            <option value="preset_custom_faculty">Custom Faculty Scheme</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-2">
                        <label class="text-xs font-weight-bold text-gray-700 text-uppercase">Passing Threshold
                            Cutoff</label>
                        <div class="input-group input-group-sm">
                            <input type="number" step="0.01" min="1.00" max="5.00"
                                class="form-control form-control-sm font-weight-bold text-danger"
                                id="modalInputPassingCutoff" value="3.04">
                            <div class="input-group-append">
                                <span class="input-group-text font-weight-bold">Cutoff</span>
                            </div>
                        </div>
                        <small class="text-xs text-muted">Grade &gt; cutoff triggers FAILED & Risk Alert.</small>
                    </div>
                </div>

                <!-- Component Weights Builder Header & Validation Badge -->
                <div
                    class="d-flex align-items-center justify-content-between p-2 mb-3 bg-white rounded border shadow-sm flex-wrap">
                    <div class="mb-1 mb-sm-0">
                        <span class="text-xs font-weight-bold text-uppercase text-gray-800">
                            <i class="fas fa-layer-group text-primary mr-1"></i> Component Weights Builder & Item
                            Adjuster
                        </span>
                    </div>
                    <div class="d-flex align-items-center">
                        <span class="badge badge-success px-3 py-2 font-weight-bold shadow-sm"
                            id="modalWeightTotalBadge" style="font-size: 0.85rem;">
                            <i class="fas fa-check-circle mr-1"></i> Total: 100% (Balanced)
                        </span>
                    </div>
                </div>

                <!-- Dynamic Component Weights Builder Container -->
                <div id="modalComponentsList">
                    <!-- Rendered by renderModalComponents() -->
                </div>

                <div class="d-flex align-items-center justify-content-between mt-3 flex-wrap">
                    <button type="button" class="btn btn-sm btn-outline-primary mb-1 mb-sm-0"
                        id="btnModalAddMainComponent">
                        <i class="fas fa-plus mr-1"></i> Add Main Component Group
                    </button>
                    <small class="text-muted font-weight-bold" id="modalValidationFeedback">All component percentage
                        weights must sum to exactly 100%.</small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-sm btn-outline-secondary" id="btnModalResetScheme">
                    <i class="fas fa-undo mr-1"></i> Reset to Preset
                </button>
                <button type="button" class="btn btn-primary font-weight-bold px-4" id="btnApplySchemeModal"
                    style="background-color: #6B1D2F; border-color: #6B1D2F;">
                    <i class="fas fa-save mr-1"></i> Save & Apply Scheme
                </button>
            </div>
        </div>
    </div>
</div>