<!-- Page Content -->
<div class="container-fluid fade-in-up">

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800 font-weight-bold">Program & Enrollment Records</h1>
            <p class="text-xs text-gray-600 mb-0">Active curriculum allocations, section registries, and program
                structural context across MarSU colleges.</p>
        </div>
        <div class="mt-3 mt-sm-0 btn-group">
            <a href="student-profile-database.html" class="btn btn-sm btn-outline-primary shadow-sm"><i
                    class="fas fa-id-card mr-1"></i> Student Profiles</a>
            <a href="academic-history.html" class="btn btn-sm btn-outline-primary shadow-sm"><i
                    class="fas fa-history mr-1"></i> Academic History</a>
        </div>
    </div>

    <!-- Contextual Academic Entities Card -->
    <div class="card shadow-sm border-left-primary mb-4"
        style="background: linear-gradient(to right, #fcf8f9, #ffffff);">
        <div class="card-body py-3">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h6 class="font-weight-bold text-primary mb-1"><i class="fas fa-sitemap mr-1"></i> Academic Entity
                        Context</h6>
                    <p class="text-xs text-muted mb-0">Undergraduate programs and section allocations are linked
                        directly to accredited academic departments, colleges, and designated faculty advisers.</p>
                </div>
                <div class="col-lg-4 text-lg-right mt-2 mt-lg-0">
                    <span class="badge badge-light border text-muted mr-1">AY 2025-2026</span>
                    <span class="badge badge-success">Enrollment Active</span>
                </div>
            </div>
        </div>
    </div>

    <!-- KPI Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-primary h-100 shadow-sm">
                <div class="kpi-label text-primary">Total Monitored Roster</div>
                <div class="kpi-number text-gray-900" id="kpiTotalEnrolled">0</div>
                <div class="text-xs text-muted mt-1">Confirmed enrolled students</div>
                <i class="fas fa-user-check kpi-icon"></i>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-success h-100 shadow-sm">
                <div class="kpi-label text-success">Regular Load</div>
                <div class="kpi-number text-gray-900" id="kpiRegular">0</div>
                <div class="text-xs text-muted mt-1">Full prescribed curriculum units</div>
                <i class="fas fa-check-double kpi-icon"></i>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-warning h-100 shadow-sm">
                <div class="kpi-label text-warning">Irregular / Partial Load</div>
                <div class="kpi-number text-gray-900" id="kpiIrregular">0</div>
                <div class="text-xs text-muted mt-1">Subject deficiencies or cross-enrolled</div>
                <i class="fas fa-user-clock kpi-icon"></i>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-info h-100 shadow-sm">
                <div class="kpi-label text-info">Active Sections</div>
                <div class="kpi-number text-gray-900" id="kpiSections">6</div>
                <div class="text-xs text-muted mt-1">Across 4 university colleges</div>
                <i class="fas fa-th-large kpi-icon"></i>
            </div>
        </div>
    </div>

    <!-- Main Enrollment Ledger Table Card -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-wrap align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">
                <i class="fas fa-clipboard-list mr-1"></i> Active Term Enrollment Ledger (AY 2025-2026 S1)
            </h6>
            <div class="btn-group btn-group-sm mt-2 mt-sm-0">
                <button type="button" class="btn btn-outline-secondary status-filter active" data-status="all">All
                    Status</button>
                <button type="button" class="btn btn-outline-success status-filter"
                    data-status="Regular">Regular</button>
                <button type="button" class="btn btn-outline-warning status-filter"
                    data-status="Irregular">Irregular</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="enrollmentTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Program</th>
                            <th>Major / Track</th>
                            <th class="text-center">Year Level</th>
                            <th class="text-center">Section</th>
                            <th class="text-center">Status</th>
                            <th>Assigned Academic Adviser</th>
                        </tr>
                    </thead>
                    <tbody id="enrollmentTableBody">
                        <!-- Loaded via MarSUDataStore -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>