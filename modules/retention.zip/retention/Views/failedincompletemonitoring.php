<!-- Page Content -->
<div class="container-fluid fade-in-up">

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800 font-weight-bold">Failed & Incomplete Subject Monitoring
            </h1>
            <p class="text-xs text-gray-600 mb-0">Institutional watch list of course failures (5.00),
                Incomplete (INC) marks, and removal examination deadlines.</p>
        </div>
        <div class="mt-3 mt-sm-0">
            <a href="grade-management.html" class="btn btn-sm btn-outline-primary shadow-sm">
                <i class="fas fa-edit fa-sm mr-1"></i> Grades Tracking
            </a>
        </div>
    </div>



    <!-- KPI Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-danger h-100 shadow-sm">
                <div class="kpi-label text-danger">Total Deficiencies</div>
                <div class="kpi-number text-gray-900" id="kpiDefTotal">4</div>
                <div class="text-xs text-muted mt-1">Active failing or incomplete marks</div>
                <i class="fas fa-times-circle kpi-icon"></i>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-warning h-100 shadow-sm">
                <div class="kpi-label text-warning">Incomplete (INC)</div>
                <div class="kpi-number text-gray-900" id="kpiDefInc">2</div>
                <div class="text-xs text-muted mt-1">Pending major requirement / project</div>
                <i class="fas fa-hourglass-half kpi-icon"></i>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-danger h-100 shadow-sm">
                <div class="kpi-label text-danger">Failed Marks (5.00)</div>
                <div class="kpi-number text-gray-900" id="kpiDefFail">2</div>
                <div class="text-xs text-muted mt-1">Mandatory subject retake required</div>
                <i class="fas fa-exclamation-circle kpi-icon"></i>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-info h-100 shadow-sm">
                <div class="kpi-label text-info">Removal Exam Pending</div>
                <div class="kpi-number text-gray-900" id="kpiDefRemoval">3</div>
                <div class="text-xs text-muted mt-1">Scheduled with college dean</div>
                <i class="fas fa-calendar-alt kpi-icon"></i>
            </div>
        </div>
    </div>

    <!-- Main Deficiency Table Card -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-wrap align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">
                <i class="fas fa-clipboard-list mr-1"></i> Active Deficiencies & Removal Tracking Ledger
            </h6>
            <div class="btn-group btn-group-sm mt-2 mt-sm-0">
                <button type="button" class="btn btn-outline-secondary def-filter active" data-filter="all">All
                    Types</button>
                <button type="button" class="btn btn-outline-danger def-filter" data-filter="Failed">Failed
                    (5.00)</button>
                <button type="button" class="btn btn-outline-warning def-filter" data-filter="INC">Incomplete
                    (INC)</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="deficiencyTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Subject</th>
                            <th class="text-center">Deficiency Type</th>
                            <th class="text-center">Term Recorded</th>
                            <th>Instructor</th>
                            <th class="text-center">Resolution Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody id="deficiencyTableBody">
                        <!-- Loaded dynamically -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>