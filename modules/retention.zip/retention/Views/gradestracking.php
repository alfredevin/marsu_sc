<!-- Page Content -->
<div class="container-fluid fade-in-up">

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800 font-weight-bold">Grades Tracking</h1>
            <p class="text-xs text-gray-600 mb-0">Official institutional class record and grade entry using MarSU's
                1.00–5.00 academic grading scale.</p>
        </div>
        <div class="mt-3 mt-sm-0">
            <button class="btn btn-sm btn-primary shadow-sm" data-toggle="modal" data-target="#encodeGradeModal">
                <i class="fas fa-edit fa-sm mr-1"></i> Encode Student Grade
            </button>
            <a href="course-performance-monitoring.html" class="btn btn-sm btn-outline-primary shadow-sm ml-1">
                <i class="fas fa-chart-bar fa-sm mr-1"></i> Course Performance
            </a>
        </div>
    </div>

    <!-- Grading Policy Banner -->
    <div class="marsu-notice-banner">
        <div class="d-flex align-items-center justify-content-between flex-wrap">
            <div>
                <h5 class="mb-1"><i class="fas fa-balance-scale mr-2"></i> MarSU Institutional Grading Scale Standard
                </h5>
                <p class="mb-0">Passing grades: <strong>1.00 (Excellent)</strong> to <strong>3.00 (Passed)</strong>.
                    Grades <strong>3.25 to 5.00</strong> represent academic deficiency or failure.</p>
            </div>
            <span class="badge badge-warning text-dark font-weight-bold mt-2 mt-md-0 px-3 py-2">AY 2025-2026 Sem 1
                Active</span>
        </div>
    </div>

    <!-- KPI Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-primary h-100 shadow-sm">
                <div class="kpi-label text-primary">Class Average GPA</div>
                <div class="kpi-number text-gray-900" id="kpiMeanGpa">2.45</div>
                <div class="text-xs text-muted mt-1">Institutional passing range (&le; 3.00)</div>
                <i class="fas fa-calculator kpi-icon"></i>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-success h-100 shadow-sm">
                <div class="kpi-label text-success">Passing Ratio</div>
                <div class="kpi-number text-gray-900" id="kpiPassRate">82.5%</div>
                <div class="text-xs text-muted mt-1">Students meeting minimum competency</div>
                <i class="fas fa-user-check kpi-icon"></i>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-danger h-100 shadow-sm">
                <div class="kpi-label text-danger">Deficient / At-Risk</div>
                <div class="kpi-number text-gray-900" id="kpiDeficientCount">2</div>
                <div class="text-xs text-muted mt-1">Grade &gt; 3.00 or Incomplete</div>
                <i class="fas fa-exclamation-triangle kpi-icon"></i>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card kpi-card border-left-info h-100 shadow-sm">
                <div class="kpi-label text-info">Total Grades Monitored</div>
                <div class="kpi-number text-gray-900" id="kpiTotalGrades">0</div>
                <div class="text-xs text-muted mt-1">Synchronized with central database</div>
                <i class="fas fa-database kpi-icon"></i>
            </div>
        </div>
    </div>

    <!-- Grades Table Card -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-wrap align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">
                <i class="fas fa-table mr-1"></i> Class Grade Registry
            </h6>
            <div class="btn-group btn-group-sm mt-2 mt-sm-0">
                <button type="button" class="btn btn-outline-secondary grade-filter active" data-filter="all">All
                    Subjects</button>
                <button type="button" class="btn btn-outline-secondary grade-filter" data-filter="IT211">IT211</button>
                <button type="button" class="btn btn-outline-secondary grade-filter" data-filter="CS101">CS101</button>
                <button type="button" class="btn btn-outline-secondary grade-filter" data-filter="CE214">CE214</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="gradesTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Subject</th>
                            <th>Instructor</th>
                            <th class="text-center">Raw Score</th>
                            <th class="text-center">Transmuted Grade</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody id="gradesTableBody">
                        <!-- Loaded via MarSUDataStore -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>