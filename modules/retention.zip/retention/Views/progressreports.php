<!-- Page Content -->
<div class="container-fluid fade-in-up">

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800 font-weight-bold">Academic Progress Reports</h1>
            <p class="text-xs text-gray-600 mb-0">Curricular completion tracking, units earned towards
                degree completion, and graduation projection audits.</p>
        </div>
        <div class="mt-3 mt-sm-0">
            <button class="btn btn-sm btn-outline-secondary shadow-sm" onclick="window.print()">
                <i class="fas fa-print fa-sm mr-1"></i> Print Cohort Audit
            </button>
        </div>
    </div>

    <!-- Main Progress Table Card -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-wrap align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">
                <i class="fas fa-tasks mr-1"></i> Per-Student Degree Completion & Milestone Audit
            </h6>
            <div class="btn-group btn-group-sm mt-2 mt-sm-0">
                <button type="button" class="btn btn-outline-secondary progress-filter active" data-filter="all">All
                    Cohorts</button>
                <button type="button" class="btn btn-outline-success progress-filter"
                    data-filter="On-Track">On-Track</button>
                <button type="button" class="btn btn-outline-warning progress-filter" data-filter="Delayed">Delayed /
                    At-Risk</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="progressTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Program</th>
                            <th class="text-center">Year Level</th>
                            <th>Curriculum Progress</th>
                            <th class="text-center">Units Earned / Total</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Target Year</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody id="progressTableBody">
                        <!-- Loaded via MarSUDataStore -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>



</div>

</div>