<!-- Course Performance Ledger Table Card -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">
            <i class="fas fa-list-alt mr-1"></i> Subject-by-Subject Performance Metrics
        </h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="coursePerfTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Course Code</th>
                        <th>Course Title</th>
                        <th>Department</th>
                        <th>Units</th>
                        <th class="text-center">Enrolled</th>
                        <th class="text-center">Mean GPA</th>
                        <th class="text-center">Passing Rate</th>
                        <th class="text-center">Status</th>
                    </tr>
                </thead>
                <tbody id="coursePerfTableBody">
                    <!-- Populated via MarSUDataStore -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Page Content -->
<div class="container-fluid fade-in-up">

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800 font-weight-bold">Subject Performance</h1>
            <p class="text-xs text-gray-600 mb-0">Subject-level academic outcomes, grade distribution
                analysis, and curricular difficulty indicators.</p>
        </div>
        <div class="mt-3 mt-sm-0">
            <a href="grade-management.html" class="btn btn-sm btn-outline-primary shadow-sm">
                <i class="fas fa-edit fa-sm mr-1"></i> Grades Tracking
            </a>
            <a href="failed-incomplete-monitoring.html" class="btn btn-sm btn-outline-danger shadow-sm ml-1">
                <i class="fas fa-exclamation-triangle fa-sm mr-1"></i> Failed & Incomplete List
            </a>
        </div>
    </div>



    <!-- Performance Comparison Charts -->
    <div class="row mb-4">
        <div class="col-lg-8 mb-4">
            <div class="card shadow h-100">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-chart-bar mr-1"></i>
                        Subject Passing Rate Comparison vs Target (85%)</h6>
                </div>
                <div class="card-body">
                    <div class="chart-bar" style="height:270px;">
                        <canvas id="coursePassingChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="card shadow h-100">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-chart-pie mr-1"></i>
                        Grade Distribution Cohort</h6>
                </div>
                <div class="card-body">
                    <div class="chart-pie pt-2 pb-2" style="height:220px;">
                        <canvas id="gradeDistributionPie"></canvas>
                    </div>
                    <div class="mt-3 text-center small text-muted">
                        <span class="mr-2"><i class="fas fa-circle text-success"></i> 1.00 - 2.00
                            (Honor)</span>
                        <span class="mr-2"><i class="fas fa-circle text-primary"></i> 2.25 - 3.00
                            (Pass)</span>
                        <span class="mr-2"><i class="fas fa-circle text-danger"></i> > 3.00
                            (Deficient)</span>
                    </div>
                </div>
            </div>
        </div>
    </div>



</div>